
import math

def sum_and_sort_numbers(a, b=math.pi, verbose=False):
    total = a + b
    sorted_numbers = sorted([a, b])

    if verbose:
        print(f"Input values: a = {a}, b = {b}")
        print(f"Sum of a and b: {total}")
        print(f"Sorted numbers: {sorted_numbers}")

    return total, sorted_numbers

result, sorted_values = sum_and_sort_numbers(7, verbose=True)

import math


def sum_and_sort_numbers(a, b=math.pi):
    """Calculate the sum of two numbers and return them in sorted order.

    Args:
        a (float): The first number.
        b (float, optional): The second number. Defaults to math.pi.

    Returns:
        tuple: A tuple containing the sum of the two numbers and a sorted list of the two numbers."""
    total = a + b
    sorted_numbers = sorted([a, b])
    return total, sorted_numbers

if __name__ == '__main__':

    result_sum, sorted_values = sum_and_sort_numbers(3, 5)
    assert result_sum == 3 + 5
    assert sorted_values == [3, 5]

    result_sum, sorted_values = sum_and_sort_numbers(-2, -6)
    assert result_sum == -2 + (-6)
    assert sorted_values == [-6, -2]

    result_sum, sorted_values = sum_and_sort_numbers(-4, 2)
    assert result_sum == -4 + 2
    assert sorted_values == [-4, 2]

    result_sum, sorted_values = sum_and_sort_numbers(9999, 10000)
    assert result_sum == 9999 + 10000
    assert sorted_values == [9999, 10000]

    print("All test cases passed!")

