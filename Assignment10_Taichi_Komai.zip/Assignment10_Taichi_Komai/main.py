import functions
help(functions)

help(functions)